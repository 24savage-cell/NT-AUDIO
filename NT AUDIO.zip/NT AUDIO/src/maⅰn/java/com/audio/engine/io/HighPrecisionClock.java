package com.audio.engine.io;

public class HighPrecisionClock {
    public long getCurrentTimeNs() {
        return System.nanoTime();
    }

    public double getCurrentTimeMs() {
        return getCurrentTimeNs() / 1000000.0;
    }
}
