package com.audio.engine.environment;

import java.util.EnumMap;
import com.audio.engine.config.ChannelDefinition;

enum SurfaceType {FLOOR, CEILING, LEFT_WALL, RIGHT_WALL, FRONT_WALL, BACK_WALL}

class MaterialProperties {
    final float reflectivity;     // 声能反射率 (0-1)
    final float scatteringCoeff; // 散射系数 (0=镜面, 1=漫反射)
    final float lowFreqAbsorption;// 低频吸收 (100Hz以下)

    public MaterialProperties(float refl, float scat, float lowAbs) {
        this.reflectivity = refl;
        this.scatteringCoeff = scat;
        this.lowFreqAbsorption = lowAbs;
    }
}

public class AcousticEnvironment {
    public final float[] roomSize;          // [width, height, depth] 米
    public final EnumMap<SurfaceType, MaterialProperties> surfaces;
    public final float airAbsorptionCoeff;  // 空气高频衰减系数 (dB/m/Hz)

    public AcousticEnvironment(float[] size) {
        this.roomSize = size.clone();
        this.surfaces = new EnumMap<>(SurfaceType.class);
        // 初始化默认材质
        surfaces.put(SurfaceType.FLOOR, new MaterialProperties(0.2f, 0.1f, 0.9f));
        // 其他墙面初始化...
        this.airAbsorptionCoeff = 0.0001f;
    }
}
