package com.audio.engine.rendering;

import java.util.ArrayList;
import java.util.List;
import com.audio.engine.config.ChannelDefinition;
import com.audio.engine.environment.AcousticEnvironment;
import com.audio.engine.environment.SurfaceType;

public class RayTracingRenderer {
    private final AcousticEnvironment env;
    private final int maxReflections;
    private List<ChannelDefinition> channels;
    private List<SoundPath> paths = new ArrayList<>();

    public RayTracingRenderer(AcousticEnvironment env, int maxReflections, List<ChannelDefinition> channels) {
        this.env = env;
        this.maxReflections = maxReflections;
        this.channels = channels;
    }

    private ChannelDefinition findReceiver(float[] pos) {
        float minDistance = Float.MAX_VALUE;
        ChannelDefinition closest = null;
        for (ChannelDefinition ch : channels) {
            if (!ch.isActive) continue;
            float[] distAttn = calculateDistance(pos, ch.position);
            float distance = distAttn[0] * 343; // 延迟转距离（米）
            if (distance < minDistance) {
                minDistance = distance;
                closest = ch;
            }
        }
        return closest;
    }

    // 其他方法不变...
}

class SoundPath {
    final ChannelDefinition receiver;
    final float delay;        // 延迟 (秒)
    final float attenuation;  // 衰减系数
    final List<SurfaceType> reflections;

    SoundPath(ChannelDefinition recv, float dly, float attn, List<SurfaceType> refl) {
        this.receiver = recv;
        this.delay = dly;
        this.attenuation = attn;
        this.reflections = new ArrayList<>(refl);
    }
}
