#ifndef NATIVE_AUDIO_DEVICE_H  
#define NATIVE_AUDIO_DEVICE_H  

// 初始化音频设备（返回0成功，非0错误码）  
int audio_device_initialize(  
    int sample_rate,    // 采样率（Hz）  
    int frame_size      // 每帧样本数  
);  

// 写入多声道音频数据（阻塞式）  
int audio_device_write(  
    float** channels,   // 二维数组：channels[channel_index][sample_index]  
    int channel_count,  // 声道数  
    int frame_size      // 帧数  
);  

// 释放设备资源  
void audio_device_release();  

#endif  // NATIVE_AUDIO_DEVICE_H  
