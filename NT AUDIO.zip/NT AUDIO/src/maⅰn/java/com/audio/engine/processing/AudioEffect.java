package com.audio.engine.processing;

public interface AudioEffect {
    float[] process(float[] input, float[] params); // 核心处理接口
    String getEffectName();                          // 获取效果器名称
    default float[] validateParams(float[] params) {  // 参数校验
        return (params != null && params.length > 0) ? params : new float[0];
    }
}
