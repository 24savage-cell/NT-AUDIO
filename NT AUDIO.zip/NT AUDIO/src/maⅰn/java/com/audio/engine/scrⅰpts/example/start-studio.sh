#!/bin/bash  
# 检查是否提供配置文件路径  
if [ -z "$1" ]; then  
  echo "请指定配置文件路径：$0 <config.json>"  
  exit 1  
fi  
# 运行主类，加载指定配置  
java -cp ../target/audio-engine-1.0-SNAPSHOT.jar com.audio.engine.example.Main "$1"  
