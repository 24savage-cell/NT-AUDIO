package com.audio.engine.integration.core;

import com.audio.engine.core.ProfessionalAudioEngine;
import com.audio.engine.config.Config;
import com.audio.engine.config.ChannelDefinition;
import com.audio.engine.environment.AcousticEnvironment;
import org.junit.Test;
import static org.junit.Assert.*;

public class EnginePipelineTest {
    @Test
    public void testEngineInitialization() {
        // 测试引擎初始化
        ChannelDefinition ch = new ChannelDefinition("test", new float[]{0, 0, 0}, new float[]{0, 0});
        AcousticEnvironment env = new AcousticEnvironment(new float[]{5, 3, 4});
        Config config = new Config(48000, 1024, List.of(ch), env);
        assertDoesNotThrow(() -> new ProfessionalAudioEngine(config));
    }
}
