#!/bin/bash  
# 清除旧构建 + 打包 + 跳过测试（生产环境用）  
mvn clean package -DskipTests  
# 输出提示  
echo "构建完成！JAR包路径：$(pwd)/target/audio-engine-1.0-SNAPSHOT.jar"  
# 可选：自动打开target目录  
open target/ 2>/dev/null || echo "可手动进入target/目录查看文件"  
