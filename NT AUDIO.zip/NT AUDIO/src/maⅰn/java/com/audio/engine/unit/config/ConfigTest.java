package com.audio.engine.unit.config;

import com.audio.engine.config.Config;
import com.audio.engine.config.ChannelDefinition;
import com.audio.engine.environment.AcousticEnvironment;
import org.junit.Test;
import static org.junit.Assert.*;

public class ConfigTest {
    @Test(expected = IllegalArgumentException.class)
    public void testInvalidSampleRate() {
        // 测试无效采样率
        new Config(0, 1024, null, null);
    }

    @Test
    public void testValidConfig() {
        // 测试有效配置
        ChannelDefinition ch = new ChannelDefinition("test", new float[]{0, 0, 0}, new float[]{0, 0});
        AcousticEnvironment env = new AcousticEnvironment(new float[]{5, 3, 4});
        Config config = new Config(48000, 1024, List.of(ch), env);
        assertNotNull(config);
    }
}
