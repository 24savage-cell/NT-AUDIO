package com.audio.engine.config;

import java.util.List;
import com.audio.engine.environment.AcousticEnvironment;

public class Config {
    public final int sampleRate;
    public final int frameSize;
    public final List<ChannelDefinition> channels;
    public final AcousticEnvironment environment;

    public Config(int sampleRate, int frameSize, List<ChannelDefinition> channels, AcousticEnvironment env) {
        if (sampleRate <= 0 || frameSize <= 0 || channels == null || channels.isEmpty()) {
            throw new IllegalArgumentException("Invalid config: sampleRate/frameSize must be positive, channels non-empty");
        }
        for (ChannelDefinition ch : channels) {
            if (ch.position == null || ch.position.length != 3 || ch.orientation == null || ch.orientation.length != 2) {
                throw new IllegalArgumentException("Invalid channel definition: position/orientation must be valid 3D/2D arrays");
            }
        }
        this.sampleRate = sampleRate;
        this.frameSize = frameSize;
        this.channels = channels;
        this.environment = env;
    }
}

public class ChannelDefinition {
    public final String channelId;
    public final float[] position;   // 三维坐标 (X,Y,Z)
    public final float[] orientation;// 指向 (方位角, 仰角) 弧度
    public final boolean isActive;

    public ChannelDefinition(String id, float[] pos, float[] orient) {
        if (pos == null || pos.length != 3 || orient == null || orient.length != 2) {
            throw new IllegalArgumentException("Position/orientation must be non-null 3D/2D arrays");
        }
        this.channelId = id;
        this.position = pos.clone();
        this.orientation = orient.clone();
        this.isActive = true;
    }
}
