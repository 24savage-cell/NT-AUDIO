package com.audio.engine.io;

import java.util.concurrent.locks.ReentrantLock;

public class MultiChannelRingBuffer {
    private final ReentrantLock lock = new ReentrantLock();
    private final float[][][] buffer;
    private int readIdx = 0, writeIdx = 0;

    public MultiChannelRingBuffer(int capacity, int channelCount, int frameSize) {
        buffer = new float[capacity][channelCount][frameSize];
    }

    public void write(float[][] channelsData) {
        lock.lock();
        try {
            int next = (writeIdx + 1) % buffer.length;
            if (next == readIdx) {
                throw new BufferOverflowException("Ring buffer is full");
            }
            // 写入逻辑...
        } finally {
            lock.unlock();
        }
    }

    public static class BufferOverflowException extends RuntimeException {
        public BufferOverflowException(String message) {
            super(message);
        }
    }
}
