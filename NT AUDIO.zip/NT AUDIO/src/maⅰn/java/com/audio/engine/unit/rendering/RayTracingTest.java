package com.audio.engine.unit.rendering;

import com.audio.engine.rendering.RayTracingRenderer;
import com.audio.engine.config.ChannelDefinition;
import com.audio.engine.environment.AcousticEnvironment;
import org.junit.Test;
import static org.junit.Assert.*;

public class RayTracingTest {
    @Test
    public void testFindReceiver() {
        // 测试查找接收声道
        AcousticEnvironment env = new AcousticEnvironment(new float[]{5, 3, 4});
        ChannelDefinition ch = new ChannelDefinition("test", new float[]{0, 0, 0}, new float[]{0, 0});
        RayTracingRenderer renderer = new RayTracingRenderer(env, 3, List.of(ch));
        assertNotNull(renderer.findReceiver(new float[]{0, 0, 0}));
    }
}
